﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OceanNavigationComplete.UI;
using OceanNavigationComplete.BL;
using OceanNavigationComplete.DL;

namespace OceanNavigationComplete
{
    class Program
    {
        static void Main(string[] args)
        {
            int OceanOption = 0;
            ShipDL.ReadFromFile();
            while(OceanOption!=5)
            {
                ShipUI.Header();
                OceanOption = ShipUI.Menu();
                ShipUI.Clearscreen();
                if(OceanOption==1)//Add ship
                {
                    ShipUI.Header();
                    ShipBL ship = ShipUI.TakeInput();
                    ShipDL.AddShipIntoList(ship);
                    bool flag = ShipDL.StoreIntoFile( ship);
                }
                else if(OceanOption==2)//View ship position
                {
                    ShipUI.Header();
                    string status=ShipUI.ViewShipPosition();
                    ShipUI.status(status);
                }
                else if(OceanOption==3)// view ship Serial number
                {
                    ShipUI.Header();
                    string status=ShipUI.ViewShipSerialNumber();
                    ShipUI.status(status);
                }
                else if(OceanOption==4)// Change Ship position
                {
                    ShipUI.Header();
                    bool status=ShipUI.changeshipposition();
                    Console.WriteLine(ShipUI.ShowStatus(status));
                }
                ShipUI.Clearscreen();
            }
        }
    }
}
