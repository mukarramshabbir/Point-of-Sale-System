﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OceanNavigationComplete.UI;
using OceanNavigationComplete.BL;

namespace OceanNavigationComplete.DL
{
    class AngleDL
    {
        public static string shipLatitudepostion(ShipBL s)
        {
            string dire = s.GetLatitude().GetDegrees() + ":" + s.GetLatitude().GetMinutes() + ":" + s.GetLatitude().GetDirection();
            return dire;
        }
        public static string shipLongitudepostion(ShipBL s)
        {
            string dire = s.GetLongitude().GetDegrees()+ ":" + s.GetLongitude().GetMinutes() + ":" + s.GetLongitude().GetDirection();
            return dire;
        }
    }
}
