﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OceanNavigationComplete.UI;
using OceanNavigationComplete.BL;
using System.IO;

namespace OceanNavigationComplete.DL
{
    class ShipDL
    {
        public static List<ShipBL> ShipList = new List<ShipBL>();

        public static bool StoreIntoFile(ShipBL Ship)
        {
            string Path = "E:\\semester 2\\OOPS\\Documentation projects\\OceanNavigationComplete\\ShipData.txt";

            if (File.Exists(Path))
            {
                StreamWriter fileVar = new StreamWriter(Path, true);
                fileVar.WriteLine(Ship.GetShipSerialNumber() + "," + Ship.GetLatitude().GetDegrees() + "," + Ship.GetLatitude().GetMinutes() + "," + Ship.GetLatitude().GetDirection()+ "," + Ship.GetLongitude().GetDegrees()+ "," + Ship.GetLongitude().GetMinutes() + "," + Ship.GetLongitude().GetDirection());
                fileVar.Flush();
                fileVar.Close();
                return true;
            }
            return false;
        }

        public static void ReadFromFile()
        {
            string Path = "E:\\semester 2\\OOPS\\Documentation projects\\OceanNavigationComplete\\ShipData.txt";

            if (File.Exists(Path))
            {
                StreamReader fileVar = new StreamReader(Path);
                string Record = "";
                while((Record=fileVar.ReadLine())!=null)
                {
                    
                    string[] SplittedRecord = Record.Split(',');
                    string ShipSerialNumber = SplittedRecord[0];
                    int LatDegree = int.Parse(SplittedRecord[1]);
                    float LatMinute = float.Parse(SplittedRecord[2]);
                    char LatDirection = char.Parse(SplittedRecord[3]);
                    int LonDegree = int.Parse(SplittedRecord[4]);
                    float LonMinute = float.Parse(SplittedRecord[5]);
                    char LonDirection = char.Parse(SplittedRecord[6]);
                    ShipBL s = new ShipBL(ShipSerialNumber, LatDegree, LatMinute, LatDirection, LonDegree, LonMinute, LonDirection);
                    ShipList.Add(s);
                }
                fileVar.Close();
            }
            else
            {
                Console.WriteLine("File does not exist");
            }
        }

        public static void AddShipIntoList(ShipBL s)
        {
            ShipList.Add(s);
        }

        public static bool ViewShipPosition(ShipBL s,string ShipSerialNumber)
        {
            if(s.GetShipSerialNumber()==ShipSerialNumber)
            {
                return true;
            }
            return false;
        }

        public static string parsedata(string record, int field)
        {
            int count = 1;
            string item = "";
            for (int i = 0; i < record.Length; i++)
            {
                if (record[i] == ' ')
                {
                    count++;
                }
                if (count == field)
                {
                    if (record[i] == ' ')
                    {
                        continue;
                    }
                    item = item + record[i];
                }
            }
            return item;
        }

        public static bool parsing(ShipBL s,string Latitude,string Longitude)
        {
            int latdeg = int.Parse(parsedata(Latitude, 1));
            float latmin = float.Parse(parsedata(Latitude, 2));
            char latdir = char.Parse(parsedata(Latitude, 3));
            int londeg = int.Parse(parsedata(Longitude, 1));
            float lonmin = float.Parse(parsedata(Longitude, 2));
            char londir = char.Parse(parsedata(Longitude, 3));
            if (ShipSerialCheck(s, latdeg, latmin, latdir, londeg, lonmin, londir))
            {
                return true;
            }
            return false;
        }

        public static bool ShipSerialCheck(ShipBL s,int LatDeg,float LatMin,char LatDir,int LonDeg,float LonMin,char LonDir)
        {
            if(s.GetLatitude().GetDegrees()==LatDeg && s.GetLatitude().GetMinutes()==LatMin && s.GetLatitude().GetDirection()==LatDir)
            {
                if(s.GetLongitude().GetDegrees()==LonDeg && s.GetLongitude().GetMinutes()==LonMin && s.GetLongitude().GetDirection()==LonDir)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool IsValidShipNumber(ShipBL s,string ShipNumber)
        {
            if(s.GetShipSerialNumber()==ShipNumber)
            {
                return true;
            }
            return false;
        }

        public static void changeshipposition(ShipBL chShip,int latdegree, float latminute, char latdirection, int londegree, float lonminute, char londirection)
        {
            chShip.GetLatitude().changeangle(latdegree, latminute, latdirection);
            chShip.GetLongitude().changeangle(londegree, lonminute, londirection);
        }
    }
}
