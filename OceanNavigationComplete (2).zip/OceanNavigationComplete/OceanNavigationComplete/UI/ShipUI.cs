﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OceanNavigationComplete.DL;
using OceanNavigationComplete.BL;

namespace OceanNavigationComplete.UI
{
    class ShipUI
    {
        public static int Menu()
        {
            
            Console.WriteLine("1.Add Ship");
            Console.WriteLine("2.View Ship Position");
            Console.WriteLine("3.View Ship Serial Number");
            Console.WriteLine("4.Change Ship Position");
            Console.WriteLine("Exit");
            Console.Write("Choose a option...");

            int option = int.Parse(Console.ReadLine());

            return option;
        }
        public static void Header()
        {
            Console.WriteLine("*******************************************");
            Console.WriteLine("             Ocean Navigation");
            Console.WriteLine("*******************************************");
        }
        public static void Clearscreen()
        {
            Console.WriteLine("Enter any number to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static ShipBL TakeInput()
        {
            Console.Write("Enter Ship Serial Number: ");
            string shipNumber = Console.ReadLine();
            Console.WriteLine("Enter Ship Latitude: \n");
            //latitude
            Console.Write("Enter Latitude's Degree : ");
            int degreeLatitude = int.Parse(Console.ReadLine());
            Console.Write("Enter Latitude's Minute : ");
            float minuteLatitude = float.Parse(Console.ReadLine());
            Console.Write("Enter Latitude's Direction: ");
            char directionLatitude = char.Parse(Console.ReadLine());
            //longitude
            Console.WriteLine("Enter Ship Longitude: \n");

            Console.Write("Enter Longitude's Degree : ");
            int degreeLongitude = int.Parse(Console.ReadLine());
            Console.Write("Enter Longitude's Minute : ");
            float minuteLongitude = float.Parse(Console.ReadLine());
            Console.Write("Enter Longitude's Direction : ");
            char directionLongitude = char.Parse(Console.ReadLine());
            ShipBL newship = new ShipBL(shipNumber, degreeLatitude, minuteLatitude, directionLatitude, degreeLongitude, minuteLongitude, directionLongitude);
            return newship;
        }

        public static string ViewShipPosition()
        {
            string item = "";
            bool flag = false;
            Console.Write("Enter ship serial number to view its position: ");
            string pos = Console.ReadLine();
            for(int i=0;i<ShipDL.ShipList.Count;i++)
            {
                if(ShipDL.ViewShipPosition(ShipDL.ShipList[i],pos))
                {
                    flag = true;
                    Console.WriteLine("Ship latitude: {0}\n", AngleDL.shipLatitudepostion(ShipDL.ShipList[i]));
                    Console.WriteLine("Ship Longitude: {0}", AngleDL.shipLongitudepostion(ShipDL.ShipList[i]));
                }
                
            }
            if(flag==true)
            {
                item = "This is Current Ship Position";
            }
            if(flag==false)
            {
                item="You entered wrong Serial number.";
            }
            return item;
        }

        public static string ViewShipSerialNumber()
        {
            string item = "";

            bool flag = false;
            Console.WriteLine("Enter the ship latitude (With Spaces): ");
            string Latitude = Console.ReadLine();
            Console.Write("Enter the Ship Lnogitude (With Spaces): ");
            string Longitude = Console.ReadLine();
            for(int i=0;i<ShipDL.ShipList.Count;i++)
            {
                if(ShipDL.parsing(ShipDL.ShipList[i],Latitude,Longitude))
                {
                    flag = true;
                    return item="Ship Serial Number: "+ ShipDL.ShipList[i].GetShipSerialNumber();
                }
            }
            if(flag==false)
            {
                 item="You entered wrong Latitude and Longitude";
            }
            return item;
        }

        public static bool changeshipposition()
        {
            string item = "";
            Console.WriteLine("Enter ship serial number to chande its position: ");
            string number = Console.ReadLine();
            bool flag = false;
            for(int i=0;i<ShipDL.ShipList.Count;i++)
            {
                if(ShipDL.IsValidShipNumber(ShipDL.ShipList[i],number))
                {
                    flag = true;
                    ShipPosition(ShipDL.ShipList[i]);
                    return true;
                }
            }
            if(flag==true)
            {
                item = "Ship Position Changed Successfully";
            }
            if(flag==false)
            {
                item="You entered wrong Serial number.";
            }

            return false;
        }

        static void ShipPosition(ShipBL chship)
        {
            Console.WriteLine("Enter Ship Latitude: \n");
            //latitude
            Console.Write("Enter Latitude's Degree : ");
            int degreeLatitude = int.Parse(Console.ReadLine());
            Console.Write("Enter Latitude's Minute : ");
            float minuteLatitude = float.Parse(Console.ReadLine());
            Console.Write("Enter Latitude's Direction: ");
            char directionLatitude = char.Parse(Console.ReadLine());
            //longitude
            Console.WriteLine("Enter Ship Longitude: \n");

            Console.Write("Enter Longitude's Degree : ");
            int degreeLongitude = int.Parse(Console.ReadLine());
            Console.Write("Enter Longitude's Minute : ");
            float minuteLongitude = float.Parse(Console.ReadLine());
            Console.Write("Enter Longitude's Direction : ");
            char directionLongitude = char.Parse(Console.ReadLine());
            ShipDL.changeshipposition(chship, degreeLatitude, minuteLatitude, directionLatitude, degreeLongitude, minuteLongitude, directionLongitude);
        }

        public static string ShowStatus(bool status)
        {
            string Item = "";
            if(status==true)
            {
                Item = "Ship Added Successfully";
            }
            else
            {
                Item = "Please Try Again";
            }
            return Item; ;
        }
        public static void status(string s)
        {
            Console.WriteLine(s);
        }
    }
}
