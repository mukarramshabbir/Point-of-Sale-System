﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OceanNavigationComplete.DL;
using OceanNavigationComplete.UI;

namespace OceanNavigationComplete.BL
{
    class ShipBL
    {
        private string ShipSerialNumber;
        private AngleBL latitude;
        private AngleBL longitude;

        public ShipBL(string ShipSerialNumber, int LatDegree, float LatMinute, char LatDirection, int LonDegree, float LonMinute, char LonDirection)
        {
            this.ShipSerialNumber = ShipSerialNumber;
            latitude = new AngleBL(LatDegree, LatMinute, LatDirection);
            longitude = new AngleBL(LonDegree, LonMinute, LonDirection);
        }
        public void SetShipSerialNumber(string ShipSerialNumber)
        {
            this.ShipSerialNumber = ShipSerialNumber;
        }
        public void SetLatitude(AngleBL Latitude)
        {
            this.latitude = Latitude;
        }
        public void SetLongitude(AngleBL Longitude)
        {
            this.longitude = Longitude;
        }
        public String GetShipSerialNumber()
        {
            return ShipSerialNumber;
        }
        public AngleBL GetLatitude()
        {
            return latitude;
        }
        public AngleBL GetLongitude()
        {
            return longitude;
        }
    }
}
