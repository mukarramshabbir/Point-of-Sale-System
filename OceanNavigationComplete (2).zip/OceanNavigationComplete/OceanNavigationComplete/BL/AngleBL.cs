﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OceanNavigationComplete.DL;
using OceanNavigationComplete.UI;

namespace OceanNavigationComplete.BL
{
    class AngleBL
    {
        private int Degrees;
        private float Minutes;
        private char Direction;

        public AngleBL(int Degrees, float Minutes, char Direction)
        {
            this.Degrees = Degrees;
            this.Minutes = Minutes;
            this.Direction = Direction;
        }
        public void SetDegrees(int Degrees)
        {
            this.Degrees = Degrees;
        }
        public void SetMinutes(float Minutes)
        {
            this.Minutes = Minutes;
        }
        public void SetDirection(char Direction)
        {
            this.Direction = Direction;
        }
        public int GetDegrees()
        {
            return Degrees;
        }
        public float GetMinutes()
        {
            return Minutes;
        }
        public char GetDirection()
        {
            return Direction;
        }

        public void changeangle(int Degrees, float Minutes, char Direction)
        {
            this.Degrees = Degrees;
            this.Minutes = Minutes;
            this.Direction = Direction;
        }
    }
}
