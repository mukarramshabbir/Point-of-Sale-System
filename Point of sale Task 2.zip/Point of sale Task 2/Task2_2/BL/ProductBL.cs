﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.UI;
using Task2_2.DL;

namespace Task2_2.BL
{
    class ProductBL // Attributes
    {
        private string ProductName;
        private string ProductCategory;
        private double ProductPrice;
        private int StockQuantity;
        private int ThresholdQuantity;

        public ProductBL(string ProductName,string ProductCategory,double ProductPrice,int StockQuantity,int ThresholdQuantity)
        {
            this.ProductName = ProductName;
            this.ProductCategory = ProductCategory;
            this.ProductPrice = ProductPrice;
            this.StockQuantity = StockQuantity;
            this.ThresholdQuantity = ThresholdQuantity;
        }
        //************ SETTER ******************
        public void SetProductName(string ProductName)
        {
            this.ProductName = ProductName;
        }
        public void SetProductCategory(string ProductCategory)
        {
            this.ProductCategory = ProductCategory;
        }
        public void SetProductPrice(double ProductPrice)
        {
            this.ProductPrice = ProductPrice;
        }
        public void SetStockQuantity(int StockQuantity)
        {
            this.StockQuantity = StockQuantity;
        }
        public void SetThresholdQuantity(int ThresholdQuantity)
        {
            this.ThresholdQuantity = ThresholdQuantity;
        }
        //****************************************
        //************* GETTER *****************
        public string GetProductCategory()
        {
            return ProductCategory;
        }
        public string GetProductName()
        {
            return ProductName;
        }
        public double GetProductPrice()
        {
            return ProductPrice;
        }
        public int GetStockQuantity()
        {
            return StockQuantity;
        }
        public int GetThresholdQuantity()
        {
            return ThresholdQuantity;
        }
    }
}
