﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.UI;
using Task2_2.DL;

namespace Task2_2.BL
{
    class CustomerBL
    {
        private string CustomerName;
        private string ProductName;
        private int ProductQuantity;
        public CustomerBL(string CustomerName,String ProductName,int ProductQuantity)
        {
            this.CustomerName = CustomerName;
            this.ProductName = ProductName;
            this.ProductQuantity = ProductQuantity;
        }

        public string GetCustomerName()
        {
            return CustomerName;
        }
        public string GetProductName()
        {
            return ProductName;
        }
        public int GetProductQuantity()
        {
            return ProductQuantity;
        }
        public void SetCustomerName(string CustomerName)
        {
            this.CustomerName = CustomerName;
        }
        public void SetProductName(string ProductName)
        {
            this.ProductName = ProductName;
        }
        public void SetProductQuantity(int ProductQuantity)
        {
            this.ProductQuantity = ProductQuantity; ;
        }
    }
}
