﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.DL;
using Task2_2.UI;

namespace Task2_2.BL
{
    class MuserBL// Perform operation on attributes
    {
        private string userName;
        private string passWord;
        private string userRole;
        public MuserBL(string userName, string passWord, string userRole)
        {
            this.userName = userName;
            this.passWord = passWord;
            this.userRole = userRole;
        }
        public MuserBL()
        {

        }
        public MuserBL(string userName, string passWord)
        {
            this.userName = userName;
            this.passWord = passWord;
        }
        public string GetUsername()
        {
            return userName;
        }
        public string GetPassword()
        {
            return passWord;
        }
        public string GetUserRole()
        {
            return userRole;
        }
        public void SetUserName(string Username)
        {
            this.userName = Username;
        }
        public void SetPasword(string Password)
        {
            this.passWord = Password;
        }
        public void SetUserrole(string Userrole)
        {
            this.userRole = Userrole;
        }
        public bool isadmin()
        {
            if (userRole == "admin")
            {
                return true;
            }
            return false;
        }
    }
}
