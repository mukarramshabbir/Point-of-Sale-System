﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.BL;
using Task2_2.UI;
using System.IO;

namespace Task2_2.DL
{
    class ProductDL
    {
        public static List<ProductBL> ProductList = new List<ProductBL>();
        public static List<ProductBL> SortedProductList = new List<ProductBL>();

        public static bool StoreInFile(ProductBL Product,string ProductPath)
        {
            string name = Product.GetProductName();
            string category = Product.GetProductCategory();
            double price = Product.GetProductPrice();
            int stock = Product.GetStockQuantity();
            int Threshold = Product.GetThresholdQuantity();
            if (File.Exists(ProductPath))
            {
                StreamWriter FileVar = new StreamWriter(ProductPath, true);
                FileVar.WriteLine(name + "," + category + "," + price + "," + stock + "," +Threshold);
                FileVar.Flush();
                FileVar.Close();
                return true;
            }
            return false;
        }
        public static void LoadFromFile(string ProductPath)
        {
            if(File.Exists(ProductPath))
            {
                string Record = "";
                StreamReader FileVar = new StreamReader(ProductPath);
                while((Record=FileVar.ReadLine())!=null)
                {
                    string[] SplittedRecord = Record.Split(',');
                    string ProductName = SplittedRecord[0];
                    string ProductCategory = SplittedRecord[1];
                    double ProductPrice = double.Parse(SplittedRecord[2]);
                    int StockQuantity=int.Parse(SplittedRecord[3]);
                    int ThresholdQuantity=int.Parse(SplittedRecord[4]);
                    ProductBL extra = new ProductBL(ProductName, ProductCategory, ProductPrice, StockQuantity, ThresholdQuantity);
                    addProductIntoList(extra);
                }
                FileVar.Close();
            }
            else
            {
                Console.WriteLine("File does not exist");
            }
        }

        public static void addProductIntoList(ProductBL p)
        {
            ProductList.Add(p);
        }

        public static List<ProductBL> SortByMerit()
        {
            SortedProductList = ProductList.OrderByDescending(o => o.GetProductPrice()).ToList();
            return SortedProductList;
        }

        public static double salestax(ProductBL p)
        {
            double tax=0;
            string category = p.GetProductCategory();
            double price = p.GetProductPrice();
            if(category=="grocery")
            {
                return tax=price * 10/100;
            }
            else if(category=="fruit")
            {
                return tax = price * 5/100;
            }
            else
            {
                return tax = price * 15 / 100;
            }
        }

        public static bool ToBeOrdered(ProductBL p)
        {
            int Stock = p.GetStockQuantity();
            int Threshold = p.GetThresholdQuantity();
            if(Stock<Threshold)
            {
                return true;
            }
            return false;
        }

        public static bool Placeorder(string productName)
        {
            for(int i=0;i<ProductDL.ProductList.Count;i++)
            {
                if(ProductDL.ProductList[i].GetProductName()==productName)
                {
                    return true;
                }
            }
            return false;
        }

        public static void addquantity(string productName,int quantity)
        {
            int total = 0;
            for (int i = 0; i < ProductDL.ProductList.Count; i++)
            {
                if (ProductDL.ProductList[i].GetProductName() == productName)
                {
                    total = ProductDL.ProductList[i].GetStockQuantity() + quantity;
                    ProductDL.ProductList[i].SetStockQuantity(total);
                }
            }
        }
    }
}
