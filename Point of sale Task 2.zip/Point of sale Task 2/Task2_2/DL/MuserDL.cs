﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Task2_2.BL;
using Task2_2.UI;

namespace Task2_2.DL
{
    class MuserDL//Search , store , load etc to perform operation on list in short CRUD
    {
        public static List<MuserBL> userlist = new List<MuserBL>();

        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    if (record[x] == ',')
                    {
                        continue;
                    }
                    item = item + record[x];
                }
            }
            return item;
        }

        public static void loaddata(string path)
        {
            //string path = "E:\\semester 2\\OOPS\\week 5\\Task2_2\\logindetails.txt";
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string userName = parseData(record, 1);
                    string userPassword = parseData(record, 2);
                    string userRole = parseData(record, 3);
                    MuserBL user = new MuserBL(userName, userPassword, userRole);
                    addUserIntoList(user);
                }
                fileVariable.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }

        public static void addUserIntoList(MuserBL s)
        {
            userlist.Add(s);
        }

        public static void storeUserIntoFile(MuserBL extra, string path)
        {
            string userName = extra.GetUsername();
            string passWord = extra.GetPassword();
            string userRole = extra.GetUserRole();
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(userName + "," + passWord + "," + userRole);
            file.Flush();
            file.Close();
        }

        public static MuserBL signin(MuserBL take)
        {
            //MuserBL take = MuserUI.takeinputwithoutrole();
            foreach (MuserBL storeduser in MuserDL.userlist)
            {
                if (storeduser.GetUsername() == take.GetUsername() && storeduser.GetPassword() == take.GetPassword())
                {
                    return storeduser;
                }
            }
            return null;
        }
    }
}
