﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.UI;
using Task2_2.BL;
using System.IO;

namespace Task2_2.DL
{
    class CustomerDL
    {
        public static List<CustomerBL> CustomerList = new List<CustomerBL>();

        public static bool StoreInFile(CustomerBL BuyProduct, string BoughtProductPath)
        {
            if (File.Exists(BoughtProductPath))
            {
                string CustomerName = BuyProduct.GetCustomerName();
                string ProductName = BuyProduct.GetProductName();
                int ProductQuantity = BuyProduct.GetProductQuantity();
                StreamWriter FileVar = new StreamWriter(BoughtProductPath, true);
                FileVar.WriteLine(CustomerName + "," + ProductName + "," + ProductQuantity);
                FileVar.Flush();
                FileVar.Close();
                return true;
            }
            return false;
        }
        public static void LoadFromFile(string BoughtProductPath)
        {
            if (File.Exists(BoughtProductPath))
            {
                string Record = "";
                StreamReader FileVar = new StreamReader(BoughtProductPath);
                while ((Record = FileVar.ReadLine()) != null)
                {
                    string[] SplittedRecord = Record.Split(',');
                    string CustomerName = SplittedRecord[0];
                    string ProductName = SplittedRecord[1];
                    int ProductQuantity = int.Parse(SplittedRecord[2]);
                    CustomerBL extra = new CustomerBL(CustomerName,ProductName, ProductQuantity);
                    AddIntoCustomerList(extra);
                }
                FileVar.Close();
            }
            else
            {
                Console.WriteLine("File does not exist");
            }
        }
        public static void AddIntoCustomerList(CustomerBL c)
        {
            CustomerList.Add(c);
        }

        public static bool isValidProductName(string productName)
        {
            for(int i=0;i<ProductDL.ProductList.Count;i++)
            {
                if(ProductDL.ProductList[i].GetProductName()==productName)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool isValidProductQuantity(string productname,int ProductQuantity)
        {
            int total = 0;
            for (int i = 0; i < ProductDL.ProductList.Count; i++)
            {
                if (ProductDL.ProductList[i].GetProductName() == productname)
                {
                    if(ProductDL.ProductList[i].GetStockQuantity()>ProductQuantity)
                    {
                        total=ProductDL.ProductList[i].GetStockQuantity() - ProductQuantity;
                        ProductDL.ProductList[i].SetStockQuantity(total);
                        return true;
                    }
                }
            }
            return false;
        }

        public static double invoice(string Productname,int productquantity)
        {
            double total = 0;
            for(int i=0;i<ProductDL.ProductList.Count;i++)
            {
                if(ProductDL.ProductList[i].GetProductName()==Productname)
                {
                    total = productquantity * ProductDL.ProductList[i].GetProductPrice();
                }
            }
            return total;
        }

        public static double invoicewithsalestax(string Productname, int productquantity)
        {
            double total = 0,t=0;

            for (int i = 0; i < ProductDL.ProductList.Count; i++)
            {
                if (ProductDL.ProductList[i].GetProductName() == Productname)
                {
                    string category=ProductDL.ProductList[i].GetProductCategory();
                    if(category=="grocery")
                    {
                        total = productquantity * ProductDL.ProductList[i].GetProductPrice();
                        t = total * 10 / 100;
                        total = total + t;
                    }
                    else if (category == "fruit")
                    {
                        total = productquantity * ProductDL.ProductList[i].GetProductPrice();
                        t = total * 5 / 100;
                        total = total + t;
                    }
                    else
                    {
                            total = productquantity * ProductDL.ProductList[i].GetProductPrice();
                            t = total * 10 / 100;
                            total=total+t;
                        }
                    }
                }
            return total;
        }
        
        
    }
}
