﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.DL;
using Task2_2.UI;
using Task2_2.BL;

namespace Task2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = "E:\\semester 2\\OOPS\\Documentation projects\\Point of sale Task 2\\logindetails.txt";
            string Productpath = "E:\\semester 2\\OOPS\\Documentation projects\\Point of sale Task 2\\Productdetails.txt";
            string BoughtProductpath = "E:\\semester 2\\OOPS\\Documentation projects\\Point of sale Task 2\\ProductBought.txt";
            MuserDL.loaddata(path);
            ProductDL.LoadFromFile(Productpath);
            CustomerDL.LoadFromFile(BoughtProductpath);
            int option = 0;
            while(option!=3)
            {
                MuserUI.header();
                option = MuserUI.menu();
                MuserUI.clearscreen();
                if(option==1)// get into the account
                {
                    MuserUI.header();
                    MuserBL user = MuserUI.takeinputwithoutrole();
                    user = MuserDL.signin(user);
                    if(user!=null)
                    {
                        if(user.isadmin())//**************admin menu***************
                        {
                            int adminoption = 0;
                            while(adminoption!=6)
                            {
                                MuserUI.header();
                                adminoption = ProductUI.AdminMenu();
                                MuserUI.clearscreen();
                                if(adminoption==1)// add products
                                {
                                    MuserUI.header();
                                    ProductBL addproduct = ProductUI.AddProduct();
                                    ProductDL.addProductIntoList(addproduct);
                                    bool status = ProductDL.StoreInFile(addproduct, Productpath);
                                    Console.WriteLine(ProductUI.ShowStatus(status));
                                    Console.WriteLine(ProductDL.ProductList.Count);
                                }
                                else if(adminoption==2)// view all products
                                {
                                    MuserUI.header();
                                    string Status=ProductUI.viewallpeoducts();
                                    ProductUI.ShowStatus(Status);
                                }
                                else if(adminoption==3)// find product with highest unit price
                                {
                                    List<ProductBL> SortedList = new List<ProductBL>();
                                    MuserUI.header();
                                    SortedList=ProductDL.SortByMerit();
                                    ProductUI.ProductWithHighestPrice(SortedList);
                                }
                                else if(adminoption==4)// view sales tax of all products
                                {
                                    MuserUI.header();
                                    ProductUI.viewSalesTax();
                                }
                                else if(adminoption==5)// Products to be ordered
                                {
                                    MuserUI.header();
                                    ProductUI.ProductsToBeOrdered();
                                }
                                MuserUI.clearscreen();
                            }
                        }

                        else//***************user menu*********************
                        {
                            int useroption = 0;
                            while(useroption!=4)
                            {
                                MuserUI.header();
                                useroption = CustomerUI.userMenu();
                                MuserUI.clearscreen();
                                if (useroption==1)// view all products
                                {
                                    MuserUI.header();
                                    ProductUI.viewallpeoducts();
                                }
                                else if(useroption==2)//Buy the products
                                {
                                    MuserUI.header();
                                    string status=CustomerUI.BuyProducts(BoughtProductpath);
                                    ProductUI.ShowStatus(status);
                                }
                                else if(useroption==3)
                                {
                                    MuserUI.header();
                                    string status=CustomerUI.GenerateInvoice();
                                    ProductUI.ShowStatus(status);
                                }
                                MuserUI.clearscreen();
                            }
                        }
                    }
                    else
                    {
                        MuserUI.header();
                        Console.WriteLine("You entered wrong username and password.");
                    }
                }
                else if(option==2)//create account
                {
                    MuserUI.header();
                    MuserBL user = MuserUI.Takeinput();
                    MuserDL.addUserIntoList(user);
                    MuserDL.storeUserIntoFile(user, path);

                }
                else if(option==3)
                {

                }
                MuserUI.clearscreen();
            }

        }
    }
}
