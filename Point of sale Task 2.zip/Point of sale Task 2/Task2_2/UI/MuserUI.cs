﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.BL;
using Task2_2.DL;

namespace Task2_2.UI
{
    class MuserUI// take input and output from console
    {
        static string path = "E:\\semester 2\\OOPS\\week 5\\Task2_1\\logindetails.txt";
        public static void header()
        {
            Console.WriteLine("**************************************************");
            Console.WriteLine("           Point of Sale Application           ");
            Console.WriteLine("**************************************************");
        }
        public static void clearscreen()
        {
            Console.WriteLine("Enter any number to continue: ");
            Console.ReadKey();
            Console.Clear();
        }
        public static int menu()
        {
            Console.WriteLine("1. Sign in");
            Console.WriteLine("2. Sign up");
            Console.WriteLine("3. Exit");
            Console.WriteLine("Enter your option: ");
            int op = int.Parse(Console.ReadLine());
            return op;
        }

        public static MuserBL Takeinput()//createaccount
        {
            Console.WriteLine("Enter the username: ");
            string username = Console.ReadLine();
            Console.WriteLine("Enter the password: ");
            string password = Console.ReadLine();
            Console.WriteLine("Enter the role: ");
            string userrole = Console.ReadLine();
            MuserBL extra = new MuserBL(username, password, userrole);
            //MuserDL.storeUserIntoFile(extra,path);
            return extra;
        }

        public static MuserBL takeinputwithoutrole()
        {
            Console.WriteLine("Enter the username: ");
            string username = Console.ReadLine();
            Console.WriteLine("Enter the password: ");
            string pssword = Console.ReadLine();
            MuserBL extra = new MuserBL(username, pssword);
            return extra;
        }
    }
}
