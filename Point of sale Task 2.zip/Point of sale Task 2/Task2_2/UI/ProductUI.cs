﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.BL;
using Task2_2.DL;

namespace Task2_2.UI
{
    class ProductUI
    {
        public static int AdminMenu()
        {
            Console.WriteLine("************** Admin Menu ***************");
            Console.WriteLine("1. Add Product");
            Console.WriteLine("2. View all products");
            Console.WriteLine("3. Find product with highest unit price");
            Console.WriteLine("4. View sales tax of all products");
            Console.WriteLine("5. Products to be ordered(Less than threshold)");
            Console.WriteLine("6. Exit");
            Console.Write("Enter your option: ");
            int op = int.Parse(Console.ReadLine());
            while(op<0 || op>6)
            {
                Console.WriteLine("You entered wrong option.Please Try Again...");
                Console.Write("Enter your option: ");
                op = int.Parse(Console.ReadLine());
            }
            return op;
        }

        public static ProductBL AddProduct()
        {
            Console.WriteLine("*************** Add Product *****************");
            Console.Write("Enter the Product name: ");
            string productname = Console.ReadLine();
            Console.Write("Enter the Product Category: ");
            string productcategory = Console.ReadLine();
            Console.WriteLine("Enter the Product price: ");
            double productprice = int.Parse(Console.ReadLine());
            Console.Write("Enter the Product stock quantity: ");
            int stockquantity = int.Parse(Console.ReadLine());
            Console.Write("Enter the minimum stock threshold quantity: ");
            int thresholdquantity = int.Parse(Console.ReadLine());
            ProductBL extra = new ProductBL(productname, productcategory,productprice, stockquantity, thresholdquantity);
            return extra;
        }//option 1
        public static string ShowStatus(bool Flag)
        {
            string item = "Added Successfully";
            if(Flag==false)
            {
                Console.WriteLine("Not added successfully");
            }
            return item;
        }

        public static string viewallpeoducts()
        {
            string Item = "";
            Console.WriteLine("************ View All Products *************");
            Console.WriteLine("Product Name \t Category \t Product Price \t Stock quantity \t Threshold");
            for(int i=0;i<ProductDL.ProductList.Count;i++)
            {
                Console.WriteLine("{0} \t\t {1} \t\t {2} \t\t {3} \t\t {4}", ProductDL.ProductList[i].GetProductName(), ProductDL.ProductList[i].GetProductCategory(),ProductDL.ProductList[i].GetProductPrice(), ProductDL.ProductList[i].GetStockQuantity(), ProductDL.ProductList[i].GetThresholdQuantity());
            }
            return Item = "All Products are Shown";
        }// option 2

        public static void ProductWithHighestPrice(List<ProductBL> SortedList)
        {
            Console.WriteLine("********** Product with highest Price **********");
            Console.WriteLine("Product Name \t Category \t Product Price \t Stock quantity \t Threshold");
            for (int i = 0; i < SortedList.Count; i++)
            {
                Console.WriteLine("{0} \t\t {1} \t\t {2} \t\t {3} \t\t {4}",SortedList[i].GetProductName(), SortedList[i].GetProductCategory(), SortedList[i].GetProductPrice(), SortedList[i].GetStockQuantity(), SortedList[i].GetThresholdQuantity());
            }
        }// option 3

        public static void viewSalesTax()
        {
            Console.WriteLine("************ View Sales Tax ************");
            for(int i=0;i<ProductDL.ProductList.Count;i++)
            {
                Console.WriteLine("1. {0} sales tax: {1}", ProductDL.ProductList[i].GetProductName(), ProductDL.salestax(ProductDL.ProductList[i]));
            }
        }// option 4

        public static void ProductsToBeOrdered()
        {
            int j = 1;
            Console.WriteLine("************** Products To Be Ordered **************");
            for(int i=0;i<ProductDL.ProductList.Count;i++)
            {
                if(ProductDL.ToBeOrdered(ProductDL.ProductList[i]))
                {
                    Console.WriteLine("{0}. {1} is below the threshold quantity.Kindly place the order.\n",j,ProductDL.ProductList[i].GetProductName());
                }
            }
            int option = 0;
            while(option<2)
            {
                option = menu();
                if(option==1)
                {
                    addnewproductquantity();
                }
            }
        }

         public static void addnewproductquantity()
        {
            Console.WriteLine("Enter the Product name: ");
            string productName = Console.ReadLine();
            if (ProductDL.Placeorder(productName))
            {
                Console.Write("Enter the Product Quantity to be added: ");
                int quantity = int.Parse(Console.ReadLine());
                ProductDL.addquantity(productName, quantity);
            }
            else
            {
                Console.WriteLine("You entered The wrong product name: ");
            }
            
        }

        public static int menu()
        {
            Console.WriteLine("1. Place the order.");
            Console.WriteLine("2. Go back.\n");
            Console.WriteLine("Enter your option: ");
            int op = int.Parse(Console.ReadLine());
            return op;
        }

        public static void ShowStatus(string Status)
        {
            Console.WriteLine(Status);
        }
    }
}
