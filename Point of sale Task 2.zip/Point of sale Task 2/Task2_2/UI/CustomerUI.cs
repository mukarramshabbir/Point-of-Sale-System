﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2_2.BL;
using Task2_2.DL;

namespace Task2_2.UI
{
    class CustomerUI
    {
        public static int userMenu()
        {
            Console.WriteLine("************** User Menu **************");
            Console.WriteLine("1. View All Products");
            Console.WriteLine("2. Buy the Products");
            Console.WriteLine("3. Generate Invoice");
            Console.WriteLine("4. Exit");
            Console.Write("Enter your option: ");
            int op = int.Parse(Console.ReadLine());
            return op;
        }

        public static string BuyProducts(string Path)
        {
            Console.WriteLine("Enter your name: ");
            string CustomerName = Console.ReadLine();
            Console.Write("Enter how manu products you want to add: ");
            int total = int.Parse(Console.ReadLine());
            string status=takeproductinput(total,CustomerName,Path);
            return status;
        }

        public static string takeproductinput(int total,string name,string Path)
        {
            string item = " ";
            for(int i=0;i<total;i++)
            {
                Console.Write("Enter the product name: ");
                string ProductName = Console.ReadLine();
                if(CustomerDL.isValidProductName(ProductName))
                {
                    Console.Write("Enter the Quantity: ");
                    int ProductQuantity = int.Parse(Console.ReadLine());
                    if(CustomerDL.isValidProductQuantity(ProductName,ProductQuantity))
                    {
                        CustomerBL extra = new CustomerBL(name,ProductName, ProductQuantity);
                        CustomerDL.AddIntoCustomerList(extra);
                        CustomerDL.StoreInFile(extra,Path);
                    }
                    else
                    {
                        Console.WriteLine("Product Quantity out of stock.");
                    }
                }
                else
                {
                    Console.WriteLine("You entered invalid product name.Please try again");
                    i--;
                }
            }
            return item = "Products Added Successfully";
        }

        public static string GenerateInvoice()
        {
            double total = 0;
            bool flag = false;
            string item = "";
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Generate Invoice: ");
            for (int i=0;i<CustomerDL.CustomerList.Count;i++)
            {
                if(CustomerDL.CustomerList[i].GetCustomerName()==name)
                {
                    total = total+ CustomerDL.invoicewithsalestax(CustomerDL.CustomerList[i].GetProductName(), CustomerDL.CustomerList[i].GetProductQuantity());
                    flag = true;
                    Console.WriteLine("{0} your product prices are: {1}",name,CustomerDL.invoice(CustomerDL.CustomerList[i].GetProductName(),CustomerDL.CustomerList[i].GetProductQuantity()));
                    Console.WriteLine("{0} your product prices with sales tax is: {1} \n", name, CustomerDL.invoicewithsalestax(CustomerDL.CustomerList[i].GetProductName(), CustomerDL.CustomerList[i].GetProductQuantity()));
                }
            }
            Console.WriteLine("Your total Payable amount:  {0} \n", total);
            if (flag == true)
            {
                item="Thanks for shooping here...";
            }
            else
            {
                item="Invalid User";
            }
            return item;
        }
    }
}
